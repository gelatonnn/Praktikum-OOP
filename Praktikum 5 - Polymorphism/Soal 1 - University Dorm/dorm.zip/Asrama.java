public interface Asrama {
    void infoAsrama();
    void daftarAsrama(Mahasiswa mhs);
}